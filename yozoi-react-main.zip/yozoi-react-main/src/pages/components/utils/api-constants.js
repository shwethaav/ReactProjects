const BaseURL = {
    BASE_URL: `${process.env.REACT_APP_BASE_URL}`,
};

export const API_CONSTANTS = {
    DOMICILIARY_SERVICES: `${BaseURL.BASE_URL}/Account/SignUpForDomiciliaryServices`,
    SERVICE_PROVIDER: `${BaseURL.BASE_URL}/Account/SignUpForServiceprovider`,
    SERVICE_PROVIDER_OTP: `${BaseURL.BASE_URL}/Account/SignUpForServiceproviderwithotp`,
    REGISTER_SERVICE_PROVIDER: `${BaseURL.BASE_URL}/Account/Register`,
    SELECT_SERVICES_DROPDOWN: `${BaseURL.BASE_URL}/DropDown/SelectServicesDropDown`,
    SELECT_COUNTRY_DROPDOWN: `${BaseURL.BASE_URL}/DropDown/CountryDropdown`,
};
export const API_METHODS = {
    GET: 'GET',
    POST: 'POST',
    DELETE: 'DELETE',
    UPDATE: 'UPDATE',
    PUT: 'PUT'
};

