import React, { useState, useEffect } from "react";
import "./RegistrationNew.scss";
import google from "../../../assets/images/Google.webp";
import OtpInput from "react-otp-input";
import { useNavigate } from "react-router-dom";
import { regex } from "../../components/utils/regex";
import Confirm from "../../components/confirmModal/confirm";
import Loader from "../../components/loader";
import { SignUpForServiceProviderWithOtp } from "../../components/utils/apicalls";
import FillDetails from "../filldetails/FillDetails";
import CryptoJS from "crypto-js";

const RegistrationNew = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [emailFix, setEmailFix] = useState("");
  const [showVerification, setShowVerification] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");
  const [timer, setTimer] = useState(60);
  const [timerRunning, setTimerRunning] = useState(false);
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [alertText, setAlertText] = useState();
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showConfirmModal1, setShowConfirmModal1] = useState(false);
  const [key, setKey] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const password = CryptoJS.enc.Utf8.parse("7819461082573529");

  const validateEmail = (Email) => {
    const emailRegex = regex.emailRegex;
    return emailRegex.test(Email);
  };

  const handleEmailChange = (event) => {
    const value = event.target.value;
    setEmail(value);

    // validate email format
    // if (!value.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)) {
    //   setErrorMessage("Invalid email format");
    // } else {
    //   setErrorMessage("");
    // }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)) {
      setErrorMessage("");

      const payload = {
        emailId: CryptoJS.AES.encrypt(
          CryptoJS.enc.Utf8.parse(email),
          password,
          {
            keySize: 128 / 8,
            iv: password,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
          }
        ).toString(),
        otp: verificationCode,
      };
      setIsShowLoader(true);
      if (payload && email) {
        SignUpForServiceProviderWithOtp((res) => {
          const { message, statusCode } = res;
          setIsShowLoader(true);
          if (statusCode === 200) {
            setIsShowLoader(false);
            setShowConfirmModal(true);
            setAlertText(message);
            setShowVerification(true);
            // window.location.reload();
          } else if (statusCode === 400) {
            setShowVerification(false);
            setShowConfirmModal(true);
            setIsShowLoader(false);
            setAlertText(message);
          } else {
            setShowVerification(false);
            setShowConfirmModal(true);
            setIsShowLoader(false);
            setAlertText(message);
          }
        }, payload);
      } else {
        setShowConfirmModal(true);
        setIsShowLoader(false);
        setAlertText("Enter the email");
        setShowVerification(false);
      }
    } else {
      setErrorMessage("Invalid email format");
    }
    // send email or mobile number to server for verification
  };

  const handleFill = () => {
    navigate("/fill");
    window.scrollTo(0, 0);
  };

  const handleVerification = (event) => {
    event.preventDefault();
    setShowVerification(true);
    const payload = {
      emailId: CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(email), password, {
        keySize: 128 / 8,
        iv: password,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }).toString(),
      otp: CryptoJS.AES.encrypt(
        CryptoJS.enc.Utf8.parse(verificationCode),
        password,
        {
          keySize: 128 / 8,
          iv: password,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        }
      ).toString(),
    };
    sessionStorage.setItem("getEmail", payload.emailId);
    setIsShowLoader(true);
    if (payload && email && verificationCode) {
      SignUpForServiceProviderWithOtp((res) => {
        const { message, statusCode } = res;
        setIsShowLoader(true);
        if (statusCode === 200) {
          setIsShowLoader(false);
          setShowConfirmModal1(true);
          setShowConfirmModal(false);
          setAlertText(message);
          setShowVerification(true);
        } else {
          setShowVerification(true);
          setShowConfirmModal(true);
          setShowConfirmModal1(false);
          setIsShowLoader(false);
          setAlertText(message);
        }
      }, payload);
    } else {
      setShowVerification(true);
      setShowConfirmModal(true);
      setShowConfirmModal1(false);
      setIsShowLoader(false);
      setAlertText("Enter one time password");
    }
  };

  const startTimer = () => {
    setTimerRunning(true);
    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);
    setTimeout(() => {
      clearInterval(interval);
      setTimerRunning(false);
      setTimer(60);
    }, 60000);
  };

  const handleResendClick = () => {
    startTimer();
    setShowVerification(true);
    // code to resend the OTP
    const payload = {
      emailId: CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(email), password, {
        keySize: 128 / 8,
        iv: password,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }).toString(),
      otp: "",
    };
    if (payload && validateEmail(email)) {
      SignUpForServiceProviderWithOtp((res) => {
        const { message, statusCode } = res;
        if (statusCode === 200) {
          setIsShowLoader(false);
          setShowConfirmModal(true);
          setAlertText(message);
          setShowVerification(true);
          // window.location.reload();
        } else {
          setShowVerification(true);
          setShowConfirmModal(false);
          setIsShowLoader(false);
          setAlertText(message);
        }
      }, payload);
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === "Backspace") {
      // remove last character from verificationCode state
      setVerificationCode((prevCode) => prevCode.slice(0, -1));
    }
  };

  return (
    <div className="new">
      <div className="new__container">
        <div className="new__top">
          <h2>Register with your email </h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="Enter Email "
              onChange={(e) => handleEmailChange(e)}
            />
            {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}
            <button type="submit">Continue</button>
          </form>
        </div>
        {/* <div className="new__line">
          <p>or</p>
        </div>
        <div className="new__bottom">
          <div className="new__buttons">
            <button>
              {" "}
              <img src={google} alt="google" /> Continue with Google
            </button>
          </div>
        </div> */}
      </div>
      <div className="none">
        <FillDetails email={emailFix} />
      </div>
      {showVerification && (
        <div className="otp">
          <form onSubmit={handleVerification} className="otp__form">
            <h4>Enter your one time password!</h4>
            <OtpInput
              className="otp__form__inputs"
              value={verificationCode}
              onChange={setVerificationCode}
              numInputs={6}
              renderSeparator={<span>-</span>}
              renderInput={(props) => (
                <input {...props} onKeyDown={handleKeyDown} />
              )}
            />
            <div className="otp__form__not">
              {timerRunning ? (
                <div>Resend OTP in {timer} seconds</div>
              ) : timer === 0 ? (
                <button>Timer Completed</button>
              ) : (
                <button onClick={handleResendClick}>Resend OTP</button>
              )}
            </div>
            <button type="submit">Verify</button>
          </form>
        </div>
      )}
      {showConfirmModal && (
        <Confirm
          buttonText={"OK"}
          isCancelRequired={false}
          confirmTitle={alertText}
          onConfirm={() => {
            setShowConfirmModal(false);
          }}
          onCancel={() => {
            setShowConfirmModal(false);
          }}
        />
      )}
      {showConfirmModal1 && (
        <Confirm
          buttonText={"OK"}
          isCancelRequired={false}
          confirmTitle={alertText}
          onConfirm={handleFill}
          onCancel={() => {
            setShowConfirmModal(false);
          }}
        />
      )}
      {isShowLoader ? <Loader /> : null}
    </div>
  );
};

export default RegistrationNew;
