import React, { useState } from 'react';
import './service-provider.scss';
import { MDBContainer, MDBRow, MDBCol } from 'mdb-react-ui-kit';
import { useNavigate } from 'react-router-dom';
import service from '../../../assets/images/about.jpg'
import { regex } from '../../components/utils/regex';
import Confirm from '../../components/confirmModal/confirm';
import Loader from '../../components/loader';
import { ForServiceprovider } from '../../components/utils/apicalls';
import Slide from 'react-reveal/Slide';

const ServiceProvider = () => {
    const navigate = useNavigate();
    const [isToggle, setIsToggle] = useState(false);
    const [firstName, setFirstName] = useState();
    const [lastName, setLastName] = useState();
    const [emailId, setEmailId] = useState();
    const [phoneNumber, setPhoneNumber] = useState();
    const [password, setPassword] = useState();
    const [message, setMessage] = useState();
    const [isShowLoader, setIsShowLoader] = useState(false);
    const [alertText, setAlertText] = useState();
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [showConfirmModal1, setShowConfirmModal1] = useState(false);

    const handleToggle = () => {
        setIsToggle(!isToggle);
    };

    const validateEmail = (Email) => {
        const emailRegex = regex.emailRegex;
        return emailRegex.test(Email);
    };

    const validatePhone = (Phone) => {
        const phoneRegex = regex.phoneRegex;
        return phoneRegex.test(Phone);
    };

    const validatePassword = (Password) => {
        const passwordRegex = regex.passwordRegex;
        return passwordRegex.test(Password);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const payload = {
            firstName: firstName,
            lastName: lastName,
            phoneNumer: phoneNumber,
            workEmail: emailId,
            password: password,
            message: message
        }

        console.log(payload)
        if (payload) {
            if (emailId && firstName && lastName && phoneNumber && password && message) {
                if (validateEmail(emailId)) {
                    if (validatePhone(phoneNumber)) {
                        if (validatePassword(password)) {
                            setIsShowLoader(true);
                            ForServiceprovider((res) => {
                                const { message, statusCode } = res;
                                if (statusCode === 200) {
                                    setIsShowLoader(false);
                                    setShowConfirmModal(true);
                                    setShowConfirmModal1(true);
                                    setAlertText(message);
                                    // window.location.reload();
                                } else {
                                    setShowConfirmModal(false);
                                    setShowConfirmModal1(true);
                                    setIsShowLoader(false);
                                    setAlertText(message);
                                }
                            }, payload)
                        } else {
                            setAlertText('Enter Valid Password');
                            setShowConfirmModal(false);
                            setShowConfirmModal1(true);
                            setIsShowLoader(false);
                        }
                    } else {
                        setAlertText('Enter Valid Phone Number');
                        setShowConfirmModal(false);
                        setShowConfirmModal1(true);
                        setIsShowLoader(false);
                    }
                } else {
                    setAlertText('Enter Valid Email');
                    setShowConfirmModal(false);
                    setShowConfirmModal1(true);
                    setIsShowLoader(false);
                }
            } else {
                setAlertText('Fill All The Required Fields');
                setShowConfirmModal(false);
                setShowConfirmModal1(true);
                setIsShowLoader(false);
            }

        }
    }

    const handleConfirm = () => {
        window.location.reload();
        setShowConfirmModal(true);
    }
    return (
        <div className='service'>
            <div className='service-provider'>
                <div className='left' style={{
                    backgroundImage: `url(${service})`,
                    backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'right'
                }}            >

                </div>
                <MDBContainer className="service-page gradient-form">
                    {/* style={{
                backgroundImage: `url(${image})`,
                backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center top'
            }} */}
                    <MDBRow className='service-container'>
                        <MDBCol className="mb-5 service-left-main">
                            <div className="d-flex flex-column service-center">
                                <div className="service-logo">
                                </div>
                                <Slide bottom>
                                    <h2>Become a service provider</h2>
                                    <p>Help your local community, work when you like and get paid</p>
                                </Slide>
                                <div className='form__input'>
                                    <Slide bottom>
                                        <label>First name *</label>
                                        <input placeholder='First name *' type='name'
                                            onChange={(event) => setFirstName(event.target.value)} />
                                    </Slide>
                                </div>
                                <div className='form__input'>
                                    <Slide bottom>
                                        <label>Last name *</label>
                                        <input placeholder='Last name *' type='name'
                                            onChange={(event) => setLastName(event.target.value)} />
                                    </Slide>
                                </div>
                                <div className='form__input'>
                                    <Slide bottom>
                                        <label>Email Address *</label>
                                        <input placeholder='Email Address *' type='email'
                                            onChange={(event) => setEmailId(event.target.value)} />
                                    </Slide>
                                </div>
                                <div className='form__input'>
                                    <Slide bottom>
                                        <label>Phone Number *</label>
                                        <input placeholder="Phone Number *"
                                            maxLength={10}
                                            onChange={(event) => setPhoneNumber(event.target.value)}
                                        />
                                    </Slide>
                                </div>
                                <div className='form__input'>
                                    <Slide bottom>
                                        <label>Password *</label>
                                        <input placeholder='Password *' type={`${isToggle ? 'text' : 'password'}`}
                                            required onChange={(event) => setPassword(event.target.value)} />
                                        <span
                                            role='button'
                                            tabIndex={0}
                                            className={`${isToggle
                                                ? 'fa fa-eye-slash service__icon'
                                                : 'fa fa-eye service__icon'
                                                }`}
                                            onClick={() => {
                                                handleToggle();
                                            }}
                                            onKeyDown={() => {
                                                handleToggle();
                                            }}
                                        ></span>
                                    </Slide>
                                </div>
                                <div className='form__input'>
                                    <Slide bottom>
                                        <label>Message *</label>
                                        <textarea rows={4} placeholder='Message *'
                                            onChange={(event) => setMessage(event.target.value)} />
                                    </Slide>
                                </div>
                                <div className="service-submit pt-1 pb-1">
                                    <Slide bottom>
                                        <button className="submit-button" onClick={handleSubmit}
                                        >Sign in</button>
                                    </Slide>
                                    {/* <a className="text-muted" href="#!">Forgot password?</a> */}
                                </div>
                            </div>
                        </MDBCol>
                    </MDBRow>
                </MDBContainer>
            </div>
            {showConfirmModal && (
                <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
                    onConfirm={() => { handleConfirm() }}
                    onCancel={() => { setShowConfirmModal(false) }} />
            )}
            {showConfirmModal1 && (
                <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
                    onConfirm={() => { setShowConfirmModal1(false) }}
                    onCancel={() => { setShowConfirmModal1(false) }} />
            )}
            {isShowLoader ? <Loader /> : null}
        </div>
    )
}

export default ServiceProvider;